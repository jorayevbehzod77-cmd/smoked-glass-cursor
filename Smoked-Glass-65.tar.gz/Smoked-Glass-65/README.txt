Smoked Glass 65% Transparent
Same 23 cursor states, sizes, hotspots, and animation as Smoked Glass.
Each visible pixel has 35% of its original opacity.
